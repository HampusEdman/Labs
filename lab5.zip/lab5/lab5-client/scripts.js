let jsonobject = null;
let jsonImg = null;
let jsonObjects = [];

document.addEventListener("DOMContentLoaded", async function(){
    console.log("HTML DOM tree loaded, and ready for manipulation.");
    // === YOUR FUNCTION CALL TO INITIATE THE GENERATION OF YOUR WEB PAGE SHOULD GO HERE ===

    await getArtistsDbName();
    
});

function submitText(){

    // overall workflow for retrieving the "value" of an input HTML element node of type text:
    // 1. get a reference to the respective input HTML element node; the easist: utilize the getElementById() function (see HTML DOM Manipulation)
    // 2. access the .value property of the referred input HTML element node

    const artistIdTextValue = document.getElementById("artist_id").value;
    console.log("Artist id:");
    console.log(artistIdTextValue);
    console.log(typeof(artistIdTextValue));
    console.log("==========");

    const artistNameTextValue = document.getElementById("artist_name").value;
    console.log("Artist name:");
    console.log(artistNameTextValue);
    console.log(typeof(artistNameTextValue));
    console.log("==========");

    const artistDescTextValue = document.getElementById("artist_desc").value;
    console.log("Description:");
    console.log(artistDescTextValue);
    console.log(typeof(artistDescTextValue));
    console.log("==========");

    const artistDiscogsTextValue = document.getElementById("artist_discogs").value;
    console.log("DiscogsURL:");
    console.log(artistDiscogsTextValue);
    console.log(typeof(artistDiscogsTextValue));
    console.log("==========");

    sendArtist(artistIdTextValue,artistDiscogsTextValue,artistNameTextValue,artistDescTextValue);
}

async function sendArtist(id,url,name,desc){

    const susJsonDataForServer = {
        _id: id,
        discogsUrl: url,
        name: name,
        description: desc
    }
    console.log("fetch");
    const response = await fetch(serverUrl + "/addArtist", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(susJsonDataForServer)
    });

    if(response.ok){
        response.json().then((jsonBody) => {
            console.log(jsonBody);
            jsonobject = jsonBody;
            loadList();
        });

    }else{
        console.log("The client request to the server was unsuccessful.");
        console.log(response.status + " | " + response.statusText);
    }

}

const serverUrl = "http://127.0.0.1:3000";

async function getArtistsDbName(){

const response = await fetch(serverUrl , {
    method: "GET",
    headers: {
        "Content-Type": "application/json",
    },
    body: null
});
if(response.ok){
    response.json().then((jsonBody) => {
        console.log("The client request to the server was successful.");
        jsonobject = jsonBody;
        loadList();
    });
    
    
}else{
    console.log("The client request tot the server was unsuccessful.");
    console.log(response.status + " | " + response.statusText);
}
}

//Get names/id
async function getArtistsDbSearch(search){
        console.log(search)
    const response = await fetch(serverUrl + "/search/" + search, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
        },
        body: null
    });
    if(response.ok){
        response.json().then((jsonBody) => {
            console.log("The client request to the server was successful.");
            jsonobject = jsonBody;
            loadList();
        });
        
        
    }else{
        console.log("The client request tot the server was unsuccessful.");
        console.log(response.status + " | " + response.statusText);
    }
}

async function searchArtist(){
    const artistNameTextValue = document.getElementById("artistname").value;
    console.log("Artist name:");
    console.log(artistNameTextValue);
    console.log(typeof(artistNameTextValue));
    console.log("==========");
    await getArtistsDbSearch(artistNameTextValue);
    console.log(jsonobject.length)
}

//Get object
async function getArtistsDb(object, callback) {
    const response = await fetch(serverUrl + "/" + object.name, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
        }
    });
    if (response.ok) {

        const response2 = await fetch(serverUrl + "/image/" + object._id , {
            method: "GET",
            headers: {
                "Content-Type": "image/png",
            }
        });

        if(response2.ok) {
    
            response2.blob().then((blobBody) => {
                jsonImg = blobBody;
                console.log(jsonImg)
                response.json().then((jsonBody) => {
                    console.log("The client request to the server was successful.");
                    console.log(jsonImg)
                    console.log(jsonBody)
                    jsonobject = jsonBody;
                    const info = writeInfo();
                    console.log(info); 
                    callback(info); // Call the callback with the data
            });
            
        });
        }
    } else {
        console.log("The client request tot the server was unsuccessful.");
        console.log(response.status + " | " + response.statusText);
    }
}

function loadList(object){
    if (document.contains(document.getElementById("artists"))) {
        document.getElementById("artists").remove();
    }

    const divContainer = document.createElement("div");
    divContainer.id = "artists";
    check = false; 
    const listElement = document.createElement("ul");

    if(object){  
        object.forEach(function(artist) {
            console.log(artist.name)
            const listItem = document.createElement("li");
            const itemInfo = document.createElement("a");
            
            itemInfo.onclick = function(){
                
                if(check){
                    if (document.contains(document.getElementById("artistInfo"))) {
                        document.getElementById("artistInfo").remove();
                        check = false;
                    }
                } 
                else if(!check){
                    getArtistsDb(artist, function(artistDb) {
                    console.log(artistDb)
                    listItem.appendChild(artistDb);
                    check = true;
                    });
                }      
            };
            
            listItem.innerHTML = artist.name;
            itemInfo.appendChild(listItem);
            listElement.appendChild(itemInfo);
        }) 
    }else{
        jsonobject.forEach(function(artist) {
        
            const listItem = document.createElement("li");
            const itemInfo = document.createElement("a");
    
    
            console.log(artist)
    
            
    
            itemInfo.onclick = function(){
                
                if(check){
                    if (document.contains(document.getElementById("artistInfo"))) {
                        document.getElementById("artistInfo").remove();
                        check = false;
                    }
                } 
                else if(!check){
                    getArtistsDb(artist, function(artistDb) {
                    console.log(artistDb)
                    listItem.appendChild(artistDb);
                    check = true;
                    });
                }      
            };
            listItem.innerHTML = artist.name;
            itemInfo.appendChild(listItem);    
            listElement.appendChild(itemInfo);
        });
    }

    
    divContainer.appendChild(listElement);

    document.body.appendChild(divContainer);
}

//Generate a layout for information
function writeInfo(){

    console.log(jsonobject[0].discogsUrl)
    const divContainer = document.createElement("div");
    divContainer.id = "artistInfo";

    const textElement = document.createElement("h1");
    textElement.innerHTML = jsonobject[0].name;
    divContainer.appendChild(textElement);
    
    /* IMAGE */
    
    const pElement = document.createElement("p");
    const imgElement = document.createElement("img");
    imgElement.src = URL.createObjectURL(jsonImg);
    imgElement.style.width = "300px";
    pElement.appendChild(imgElement);
    divContainer.appendChild(pElement); 

    const linkArtist = document.createElement("a");
    linkArtist.innerHTML = jsonobject[0].discogsUrl;
    linkArtist.href = jsonobject[0].discogsUrl;
    linkArtist.target = "_blank";
    divContainer.appendChild(linkArtist);

    if(jsonobject[0].realname != null){
        const textReal = document.createElement("h2");
        textReal.innerHTML = "Real name: " + jsonobject[0].realname;
        divContainer.appendChild(textReal);
    }

    const textDesc = document.createElement("p");
    textDesc.innerHTML = jsonobject[0].description;
    divContainer.appendChild(textDesc);

    if(jsonobject[0].nameVariations){
        const divNameVar = document.createElement("div");
        divNameVar.id = "artistNameVariations";
        const headNameVar = document.createElement("h3");
        headNameVar.innerHTML = "Name Variations:"
        divNameVar.appendChild(headNameVar);
        const listNameVar = document.createElement("ul");
        for(let i = 0; i < jsonobject[0].nameVariations.length; i++){
            const itemNameVar = document.createElement("li");
            itemNameVar.innerHTML = jsonobject[0].nameVariations[i];
            listNameVar.appendChild(itemNameVar);
        }
        divNameVar.appendChild(listNameVar);
        divContainer.appendChild(divNameVar);
    }
    
    if(jsonobject[0].aliases){
        const divAliases = document.createElement("div");
        divAliases.id = "artistAliases";
        const headAliases = document.createElement("h3");
        headAliases.innerHTML = "Aliases:"
        divAliases.appendChild(headAliases);
        const listAliases = document.createElement("ul");
        for(let i = 0; i < jsonobject[0].aliases.length; i++){
            const itemAliases = document.createElement("li");
            itemAliases.innerHTML = jsonobject[0].aliases[i].name;
            listAliases.appendChild(itemAliases);
        }
        divAliases.appendChild(listAliases);
        divContainer.appendChild(divAliases);
    }

    if(jsonobject[0].memberInGroups){
        const divGroups = document.createElement("div");
        divGroups.id = "artistGroups";
        const headGroups = document.createElement("h3");
        headGroups.innerHTML = "Groups:"
        divGroups.appendChild(headGroups);
        const listGroups = document.createElement("ul");
        for(let i = 0; i < jsonobject[0].memberInGroups.length; i++){
            const itemGroups = document.createElement("li");
            itemGroups.innerHTML = jsonobject[0].memberInGroups[i].name + " | Active: " + jsonobject[0].memberInGroups[i].activeInGroup;
            listGroups.appendChild(itemGroups);
        }
        divGroups.appendChild(listGroups);
        divContainer.appendChild(divGroups);
    }

    if(jsonobject[0].referenceUrls){
        const divRef = document.createElement("div");
        divRef.id = "artistGroups";
        const headRef = document.createElement("h3");
        headRef.innerHTML = "References:"
        divRef.appendChild(headRef);
        const listRefs = document.createElement("ul");
        for(let i = 0; i < jsonobject[0].referenceUrls.length; i++){
            const linkRef = document.createElement("a");
            linkRef.href = jsonobject[0].referenceUrls[i];
            linkRef.target = "_blank";
            
            const itemRef = document.createElement("li");
            itemRef.innerHTML = jsonobject[0].referenceUrls[i];
            linkRef.appendChild(itemRef);

            listRefs.appendChild(linkRef);
        }
        divRef.appendChild(listRefs);
        divContainer.appendChild(divRef);
    }
    
    return divContainer;

}