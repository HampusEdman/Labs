// declaration and loading (inclusion) of various modules
const http = require("node:http");
const MongoClient = require("mongodb").MongoClient;
const fs = require("node:fs"); 

//MongoDB server
const dbHostname = "127.0.0.1";
const dbPort = 27017;
const dbServerUrl = "mongodb://" + dbHostname + ":" + dbPort + "";

// inizialize MongoDB connector instance
const dbClient = new MongoClient(dbServerUrl);

// initialization of server properties
const hostname = "127.0.0.1";
const port = 3000;
const serverUrl = "http://" + hostname + ":" + port + "";

// initialization of server object
const server = http.createServer(async (req, res) => {
    console.log("create server");
    const requestUrl = new URL(serverUrl + req.url);
    const pathComponents = requestUrl.pathname.split("/");
    console.log("COMPONETS: " + pathComponents)
    const artistName = decodeURIComponent(requestUrl.pathname.substring(1));
    console.log("Artist name is : " + artistName)
    
    if(req.method == "GET"){
        if(pathComponents[1] === "search"){
            const dbArtist = await getDatabaseSearch(pathComponents[2]);
            routing_data(res, JSON.stringify(dbArtist));
        }
        else if(pathComponents[1] === "image"){
            routing_image(res, pathComponents)
            
        }else if(artistName){
            console.log("HERE")
            const dbArtist = await getDatabase(artistName);
            routing_data(res, JSON.stringify(dbArtist));
        }
        else{
            const dbArtistName = await getDbName();
            routing_data(res, JSON.stringify(dbArtistName));
        }
        
    }
    else if(req.method == "OPTIONS"){
        sendResponse(res, 204, null, null);
    }
    else if(req.method == "POST"){
        console.log("post");
        switch(pathComponents[1]){
            case "addArtist":
                // container (array) for collecting all received "chunks"
                const bodyChunks = [];

                // an error occuredd
                req.on("error", (err) => {
                    console.log("An error ocurred when reading the HTTP POST message's body: "
                        + err.message);
                    sendResponse(res, 500, null, null); //Server based error
                });
                // a new chunk of data has been received: "collect it"
                req.on("data", (chunk) => {
                    bodyChunks.push(chunk);
                });
                // the last chunk of data has been received
                req.on("end", () => {
                    const messageBody = Buffer.concat(bodyChunks).toString();
                    console.log("end before rout");
                    console.log(messageBody)
                    routing_score(res, messageBody);
                });
                break;
            
            default:
                sendResponse(res, 400, "text/plain", "A HTTP POST method has been sent to the server,"
                 + "but no specific API endpoint could be determined.");
        }
    }
});

// start up of the initialized (and configured) server
server.listen(port, hostname, () => {
    console.log("The server running and listening at\n" + serverUrl);
});

// convenience function (template) for composing a HTTP response message
function sendResponse(res, statusCode, contentType, data){
    //configure HTTP response status code, and (if required) Content-Type header
    console.log("sendResponse");
    res.statusCode = statusCode;
    if(contentType != null){
        res.setHeader("Content-Type", contentType);
    }

    // configure HTTP response message header to allow Cross-Origin Resource 
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "*");

    if(data != null){
        res.end(data);      //data in HTTP message body
    }else{  
        res.end();          //empty HTTP message body
    }
}

function routing_score(res, jsonString){
    const artistJsonDataFromClient = JSON.parse(jsonString);
    console.log(artistJsonDataFromClient);

    if(artistJsonDataFromClient == null){
        sendResponse(res, 406, null, null);
    }else{
        insertArtistResultsToDatabase(artistJsonDataFromClient)
        .catch(console.error)
        .finally(() => {
            sendResponse(res, 200, "application/json", JSON.stringify(obejct));
            dbClient.close(); 
        })     
    }
}
let obejct;
async function insertArtistResultsToDatabase(artistJsonDataFromClient){
    /*const dbSusDocuement = {
        _id: artistJsonDataFromClient.id,
        discogsUrl: artistJsonDataFromClient.discogsUrl,
        name: artistJsonDataFromClient.name,
        description: artistJsonDataFromClient.desc
    };*/

    await dbClient.connect();
    const db = dbClient.db("tnm115-lab");
    const dbCollection = db.collection("artists");
    const insertResult = await dbCollection.insertOne(artistJsonDataFromClient);
    console.log("Inserted Artist Document:", insertResult);
    const dbname = await getDbName();
    obejct = dbname;
}

function routing_data(res, jsonString) {
    try {
        const artistsJsonDataFromDb = JSON.parse(jsonString);
        console.log(1, artistsJsonDataFromDb);

        sendResponse(res, 200, "application/json", jsonString);

    } catch (error) {
        // Handle JSON parsing error
        console.error("Error parsing JSON:", error);
        sendResponse(res, 500, "text/plain", "Internal Server Error");
    }
}

async function getDbName(){
    const db = dbClient.db("tnm115-lab");
    const dbCollection = db.collection("artists");

    const filterQuery = {};
    const sortQuery = {name: 1};
    const projectionQuery = { _id: 1, name: 1};
    const findResult = await dbCollection.find(filterQuery).sort(sortQuery).project(projectionQuery).toArray();
    //console.log("Found/Projected Documents:", findResult);
    return findResult;
}

async function getDatabase(searchName){
    await dbClient.connect();
    const db = dbClient.db("tnm115-lab");
    const dbCollection = db.collection("artists");  
    
    console.log(searchName)

    const filterQuery = {name: searchName};
    const sortQuery = {name: 1};
    const findResult = await dbCollection.find(filterQuery).sort(sortQuery).toArray();
    //console.log("Found/Projected Documents:", findResult);

    return findResult;
}

async function getDatabaseSearch(searchName){
    await dbClient.connect();
    const db = dbClient.db("tnm115-lab");
    const dbCollection = db.collection("artists");  
    
    const indexResult = await dbCollection.createIndex({
        name: "text",
        description: "text",
        realname: "text",
    });

    console.log(searchName)

    const textQuery = { $text: { $search: searchName }};
    const sortQuery = {name: 1};
    const findResult = await dbCollection.find(textQuery).sort(sortQuery).toArray();
    //console.log("Found/Projected Documents:", findResult);

    return findResult;
}

function routing_image(res, pathComponents){

    // implementation of some simple error handling:
    // check if there is an insufficient amount of components in the URL's pathname
    if(pathComponents.length <= 2) sendResponse(res, 400, null, null);  // if no imageName was present in the URL, respond with 400 (Bad Request); docs: https://developer.mozilla.org/en-US/docs/Web/HTTP/Status#client_error_responses
    else {

        // construct the image file path, based on the internal server directory/files organization
        const imageFilePath = "./media/" + pathComponents[2] + ".png";      // observe: ./ at the beginning indicates that the following filepath is relative to THIS file (app.js); in this case, the "media" directory is on the same file level as the "app.js" file

        // utilize the (loaded) File System's readFile(filepath, callback) function, to read the contents of the (image) file
        // including using the JavaScript's Arrow function expression to define an anonymous callback function directly with
        // two available parameters: err (an error object), and data (representing the successfully read data)
        fs.readFile(imageFilePath, (err, data) => {

            // error handling
            if(err){
                console.log("An error ocurred when attempting to read the file at: " + imageFilePath);
                const imagePlaceholder = "./media/PLACEHOLDER.png";
                fs.readFile(imagePlaceholder, function(err, data) {
                    if(err) throw err;
                    sendResponse(res, 200, "image/png", data);
                })
                //sendResponse(res, 404, null, null); // respond with 404 (Not Found); docs: https://developer.mozilla.org/en-US/docs/Web/HTTP/Status#client_error_responses
            } 
            // success handling
            else {
                // send read (serialized) file data as MIME type "image/svg+xml"
                sendResponse(res, 200, "image/png", data); 
            }
        });
    }
}